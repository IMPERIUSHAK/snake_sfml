////////////
/////////////////                               SNAKE SNAKE SNAKE SNAKE SNAKE SNAKE SNAKE SNAKE
//////////////////////////
#include<iostream>
#include<SFML/Graphics.hpp>
#include<stdlib.h>
using namespace std;
int main() {

	sf::RenderWindow window(sf::VideoMode::getDesktopMode(), "Snaky");
	int l, k,sizex=50,sizey=50;
	sf::RectangleShape snake(sf::Vector2f(sizex, sizey));
	snake.setOrigin(25, 25);
	l = sf::VideoMode::getDesktopMode().width;
	k = sf::VideoMode::getDesktopMode().height;
	sf::RectangleShape Cage(sf::Vector2f(l, k));
	Cage.setOutlineThickness(1);
	Cage.setOutlineColor(sf::Color::Red);
	Cage.setFillColor(sf::Color::Black);
	double spx = 0,spy=0;
	window.setFramerateLimit(60);
	int randx, randy;
	sf::RectangleShape apple(sf::Vector2f(20, 20));
	apple.setPosition(200, 200);
	apple.setFillColor(sf::Color::Red);
	double tx = 5, score = 0;
	while (window.isOpen()) {
		sf::Event event;
		if (window.pollEvent(event)) {
			if (event.type == sf::Event::EventType::Closed) {
				window.close();
			}
		}
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::W)) {
			if (tx == 0) { tx = 5; }
			spx = 0; spy = -tx;
			snake.setRotation(90);
		}
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::S)) {
			if (tx == 0) { tx = 5; }
			spx = 0, spy = tx; snake.setRotation(-90);
			
		}
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::D)) {
			if (tx == 0) { tx = 5; }
			spx = tx; spy = 0; snake.setRotation(180);
		}
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::A)) {
			if (tx == 0) { tx = 5; }
			spx = -tx; spy = 0; snake.setRotation(0);
		}
		snake.move(spx, spy);
		if (snake.getGlobalBounds().intersects(apple.getGlobalBounds())) {
			apple.setPosition(rand() % (l - 400), rand() % (k - 300)); \
				sizex += 20; 
			snake.setSize(sf::Vector2f(sizex, sizey));
			tx+=0.5;
			score++;
		}
		int getx = snake.getPosition().x;
		int gety = snake.getPosition().y;
		if (getx>l || gety>k || getx<-1 || gety<-1) {
			snake.setPosition(0, 0); tx = 0;
			sizex = 50, sizey = 50;
			snake.setSize(sf::Vector2f(sizex, sizey));
		}
		window.clear(sf::Color::Black);
		window.draw(Cage);
		window.draw(snake);
		window.draw(apple);
		window.display();
	}
}